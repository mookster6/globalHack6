'''
Created on Oct 22, 2016

@author: Ron
'''
from tkinter import *
from tkinter.tix import IMMEDIATE

#gridX is a placeholder to allow the program to be test run with no errors while a button has no finished function
global gridX

class homelessGUI(Frame):
    def __init__(self):
        Frame.__init__(self)
        self.master.title("Help the Homeless App Demo")
        self.grid()


        
        self._listPane = Frame(self)
        self._listPane.grid(row = 0, column = 0, sticky = N+S)
        
        self._yScroll = Scrollbar(self._listPane,
                                  orient = VERTICAL)
        self._yScroll.grid(row = 0, column = 1, sticky = N+S)
        
        self._theList = Listbox(self._listPane,
                                width = 20,
                                height = 10,
                                selectmode = SINGLE,
                                yscrollcommand = self._yScroll.set)
        self._theList.grid(row = 0, column = 0, sticky = N+S)
        self._yScroll["command"] = self._theList.yview()
        

        
        def clickOn(e):
            _testText()

        def _testText():
                print ("Hi")
                    
        self._theList.insert(0, "Homeless Shelter A")
        self._theList.insert(1, "Homeless Shelter B")
        self._theList.insert(2, "Veteran's Shelter A")
        self._theList.insert(3, "Church A")
        self._theList.insert(4, "Hospital A")
        self._theList.insert(5, "Homeless Person A")
        self._theList.insert(6, "Homeless Person B")
        self._theList.insert(7, "Homeless Person C")
        self._theList.insert(8, "At Risk Individual A")
        self._theList.insert(9, "At Risk Individual B")
        self._theList.insert(10, "At Risk Individual C")
        self._theList.insert(11, "Recovering Addict A")
        self._theList.insert(12, "Disabled Individual A")
        self._theList.insert(13, "Disabled Individual A")
    
        self._theList.activate(0)
        
        self._theList.bind('<<ListboxSelect>>', clickOn)
#                 
      
        
        
            
        
        
        self.rowconfigure(0, weight = 1)
        self._listPane.rowconfigure(0, weight = 1)
        
        
        
        
        self._theMap = Frame(self)
        self._theMap.grid(row = 0 , column = 3)
#         self._theMap = Toplevel()
#         self._theMap.title("Demo of Map Overview")
        
        #row 1
        self._grid1x1png = PhotoImage(file = "StLGrid1x1.png")
        self._grid2x1png = PhotoImage(file = "StLGrid2x1.png")
        self._grid3x1png = PhotoImage(file = "StLGrid3x1.png")
        self._grid4x1png = PhotoImage(file = "StLGrid4x1.png")
        self._grid5x1png = PhotoImage(file = "StLGrid5x1.png")
        self._grid6x1png = PhotoImage(file = "StLGrid6x1.png")
        self._grid7x1png = PhotoImage(file = "StLGrid7x1.png")
        self._grid8x1png = PhotoImage(file = "StLGrid8x1.png")
        self._grid9x1png = PhotoImage(file = "StLGrid9x1.png")
        self._grid10x1png = PhotoImage(file = "StLGrid10x1.png")
        
        #row 2
        self._grid1x2png = PhotoImage(file = "StLGrid1x2.png")
        self._grid2x2png = PhotoImage(file = "StLGrid2x2.png")
        self._grid3x2png = PhotoImage(file = "StLGrid3x2.png")
        self._grid4x2png = PhotoImage(file = "StLGrid4x2.png")
        self._grid5x2png = PhotoImage(file = "StLGrid5x2.png")
        self._grid6x2png = PhotoImage(file = "StLGrid6x2.png")
        self._grid7x2png = PhotoImage(file = "StLGrid7x2.png")
        self._grid8x2png = PhotoImage(file = "StLGrid8x2.png")
        self._grid9x2png = PhotoImage(file = "StLGrid9x2.png")
        self._grid10x2png = PhotoImage(file = "StLGrid10x2.png")
        
        #row3
        self._grid1x3png = PhotoImage(file = "StLGrid1x3.png")
        self._grid2x3png = PhotoImage(file = "StLGrid2x3.png")
        self._grid3x3png = PhotoImage(file = "StLGrid3x3.png")
        self._grid4x3png = PhotoImage(file = "StLGrid4x3.png")
        self._grid5x3png = PhotoImage(file = "StLGrid5x3.png")
        self._grid6x3png = PhotoImage(file = "StLGrid6x3.png")
        self._grid7x3png = PhotoImage(file = "StLGrid7x3.png")
        self._grid8x3png = PhotoImage(file = "StLGrid8x3.png")
        self._grid9x3png = PhotoImage(file = "StLGrid9x3.png")
        self._grid10x3png = PhotoImage(file = "StLGrid10x3.png")
        
        #row 4
        self._grid1x4png = PhotoImage(file = "StLGrid1x4.png")
        self._grid2x4png = PhotoImage(file = "StLGrid2x4.png")
        self._grid3x4png = PhotoImage(file = "StLGrid3x4.png")
        self._grid4x4png = PhotoImage(file = "StLGrid4x4.png")
        self._grid5x4png = PhotoImage(file = "StLGrid5x4.png")
        self._grid6x4png = PhotoImage(file = "StLGrid6x4.png")
        self._grid7x4png = PhotoImage(file = "StLGrid7x4.png")
        self._grid8x4png = PhotoImage(file = "StLGrid8x4.png")
        self._grid9x4png = PhotoImage(file = "StLGrid9x4.png")
        self._grid10x4png = PhotoImage(file = "StLGrid10x4.png")
        
        #row5
        self._grid1x5png = PhotoImage(file = "StLGrid1x5.png")
        self._grid2x5png = PhotoImage(file = "StLGrid2x5.png")
        self._grid3x5png = PhotoImage(file = "StLGrid3x5.png")
        self._grid4x5png = PhotoImage(file = "StLGrid4x5.png")
        self._grid5x5png = PhotoImage(file = "StLGrid5x5.png")
        self._grid6x5png = PhotoImage(file = "StLGrid6x5.png")
        self._grid7x5png = PhotoImage(file = "StLGrid7x5.png")
        self._grid8x5png = PhotoImage(file = "StLGrid8x5.png")
        self._grid9x5png = PhotoImage(file = "StLGrid9x5.png")
        self._grid10x5png = PhotoImage(file = "StLGrid10x5.png")
        
        #row6
        self._grid1x6png = PhotoImage(file = "StLGrid1x6.png")
        self._grid2x6png = PhotoImage(file = "StLGrid2x6.png")
        self._grid3x6png = PhotoImage(file = "StLGrid3x6.png")
        self._grid4x6png = PhotoImage(file = "StLGrid4x6.png")
        self._grid5x6png = PhotoImage(file = "StLGrid5x6.png")
        self._grid6x6png = PhotoImage(file = "StLGrid6x6.png")
        self._grid7x6png = PhotoImage(file = "StLGrid7x6.png")
        self._grid8x6png = PhotoImage(file = "StLGrid8x6.png")
        self._grid9x6png = PhotoImage(file = "StLGrid9x6.png")
        self._grid10x6png = PhotoImage(file = "StLGrid10x6.png")
        
        #row7
        self._grid1x7png = PhotoImage(file = "StLGrid1x7.png")
        self._grid2x7png = PhotoImage(file = "StLGrid2x7.png")
        self._grid3x7png = PhotoImage(file = "StLGrid3x7.png")
        self._grid4x7png = PhotoImage(file = "StLGrid4x7.png")
        self._grid5x7png = PhotoImage(file = "StLGrid5x7.png")
        self._grid6x7png = PhotoImage(file = "StLGrid6x7.png")
        self._grid7x7png = PhotoImage(file = "StLGrid7x7.png")
        self._grid8x7png = PhotoImage(file = "StLGrid8x7.png")
        self._grid9x7png = PhotoImage(file = "StLGrid9x7.png")
        self._grid10x7png = PhotoImage(file = "StLGrid10x7.png")
        
        #row8
        self._grid1x8png = PhotoImage(file = "StLGrid1x8.png")
        self._grid2x8png = PhotoImage(file = "StLGrid2x8.png")
        self._grid3x8png = PhotoImage(file = "StLGrid3x8.png")
        self._grid4x8png = PhotoImage(file = "StLGrid4x8.png")
        self._grid5x8png = PhotoImage(file = "StLGrid5x8.png")
        self._grid6x8png = PhotoImage(file = "StLGrid6x8.png")
        self._grid7x8png = PhotoImage(file = "StLGrid7x8.png")
        self._grid8x8png = PhotoImage(file = "StLGrid8x8.png")
        self._grid9x8png = PhotoImage(file = "StLGrid9x8.png")
        self._grid10x8png = PhotoImage(file = "StLGrid10x8.png")
        
        #row9
        self._grid1x9png = PhotoImage(file = "StLGrid1x9.png")
        self._grid2x9png = PhotoImage(file = "StLGrid2x9.png")
        self._grid3x9png = PhotoImage(file = "StLGrid3x9.png")
        self._grid4x9png = PhotoImage(file = "StLGrid4x9.png")
        self._grid5x9png = PhotoImage(file = "StLGrid5x9.png")
        self._grid6x9png = PhotoImage(file = "StLGrid6x9.png")
        self._grid7x9png = PhotoImage(file = "StLGrid7x9.png")
        self._grid8x9png = PhotoImage(file = "StLGrid8x9.png")
        self._grid9x9png = PhotoImage(file = "StLGrid9x9.png")
        self._grid10x9png = PhotoImage(file = "StLGrid10x9.png")
        
        #row10
        self._grid1x10png = PhotoImage(file = "StLGrid1x10.png")
        self._grid2x10png = PhotoImage(file = "StLGrid2x10.png")
        self._grid3x10png = PhotoImage(file = "StLGrid3x10.png")
        self._grid4x10png = PhotoImage(file = "StLGrid4x10.png")
        self._grid5x10png = PhotoImage(file = "StLGrid5x10.png")
        self._grid6x10png = PhotoImage(file = "StLGrid6x10.png")
        self._grid7x10png = PhotoImage(file = "StLGrid7x10.png")
        self._grid8x10png = PhotoImage(file = "StLGrid8x10.png")
        self._grid9x10png = PhotoImage(file = "StLGrid9x10.png")
        self._grid10x10png = PhotoImage(file = "StLGrid10x10.png")
        
        
        #setting up the buttons
        
        #row 1
        self._grid1x1Button = Button(self._theMap, image = self._grid1x1png, command = self._event1x1)
        self._grid1x1Button.grid(row=0,column=1)
        
        self._grid2x1Button = Button(self._theMap, image = self._grid2x1png, command = self._event2x1)
        self._grid2x1Button.grid(row=0,column=2)
        
        self._grid3x1Button = Button(self._theMap, image = self._grid3x1png, command = self._event3x1)
        self._grid3x1Button.grid(row=0,column=3)
        
        self._grid4x1Button = Button(self._theMap, image = self._grid4x1png, command = self._event4x1)
        self._grid4x1Button.grid(row=0,column=4)
        
        self._grid5x1Button = Button(self._theMap, image = self._grid5x1png, command = self._event5x1)
        self._grid5x1Button.grid(row=0,column=5)
        
        self._grid6x1Button = Button(self._theMap, image = self._grid6x1png, command = self._event6x1)
        self._grid6x1Button.grid(row=0,column=6)
        
        self._grid7x1Button = Button(self._theMap, image = self._grid7x1png, command = self._event7x1)
        self._grid7x1Button.grid(row=0,column=7)
        
        self._grid8x1Button = Button(self._theMap, image = self._grid8x1png, command = self._event8x1)
        self._grid8x1Button.grid(row=0,column=8)
        
        self._grid9x1Button = Button(self._theMap, image = self._grid9x1png, command = self._event9x1)
        self._grid9x1Button.grid(row=0,column=9)
        
        self._grid10x1Button = Button(self._theMap, image = self._grid10x1png, command = self._event10x1)
        self._grid10x1Button.grid(row=0,column=10)
        
        #row 2
        self._grid1x2Button = Button(self._theMap, image = self._grid1x2png, command = self._event1x2)
        self._grid1x2Button.grid(row=1,column=1)
        
        self._grid2x2Button = Button(self._theMap, image = self._grid2x2png, command = self._event2x2)
        self._grid2x2Button.grid(row=1,column=2)
        
        self._grid3x2Button = Button(self._theMap, image = self._grid3x2png, command = self._event3x2)
        self._grid3x2Button.grid(row=1,column=3)
        
        self._grid4x2Button = Button(self._theMap, image = self._grid4x2png, command = self._event4x2)
        self._grid4x2Button.grid(row=1,column=4)
        
        self._grid5x2Button = Button(self._theMap, image = self._grid5x2png, command = self._event5x2)
        self._grid5x2Button.grid(row=1,column=5)
        
        self._grid6x2Button = Button(self._theMap, image = self._grid6x2png, command = self._event6x2)
        self._grid6x2Button.grid(row=1,column=6)
        
        self._grid7x2Button = Button(self._theMap, image = self._grid7x2png, command = self._event7x2)
        self._grid7x2Button.grid(row=1,column=7)
        
        self._grid8x2Button = Button(self._theMap, image = self._grid8x2png, command = self._event8x2)
        self._grid8x2Button.grid(row=1,column=8)
        
        self._grid9x2Button = Button(self._theMap, image = self._grid9x2png, command = self._event9x2)
        self._grid9x2Button.grid(row=1,column=9)
        
        self._grid10x2Button = Button(self._theMap, image = self._grid10x2png, command = self._event10x2)
        self._grid10x2Button.grid(row=1,column=10)
        
        #row3
        self._grid1x3Button = Button(self._theMap, image = self._grid1x3png, command = self._event1x3)
        self._grid1x3Button.grid(row=2,column=1)
        
        self._grid2x3Button = Button(self._theMap, image = self._grid2x3png, command = self._event2x3)
        self._grid2x3Button.grid(row=2,column=2)
        
        self._grid3x3Button = Button(self._theMap, image = self._grid3x3png, command = self._event3x3)
        self._grid3x3Button.grid(row=2,column=3)
        
        self._grid4x3Button = Button(self._theMap, image = self._grid4x3png, command = self._event4x3)
        self._grid4x3Button.grid(row=2,column=4)
        
        self._grid5x3Button = Button(self._theMap, image = self._grid5x3png, command = self._event5x3)
        self._grid5x3Button.grid(row=2,column=5)
        
        self._grid6x3Button = Button(self._theMap, image = self._grid6x3png, command = self._event6x3)
        self._grid6x3Button.grid(row=2,column=6)
        
        self._grid7x3Button = Button(self._theMap, image = self._grid7x3png, command = self._event7x3)
        self._grid7x3Button.grid(row=2,column=7)
        
        self._grid8x3Button = Button(self._theMap, image = self._grid8x3png, command = self._event8x3)
        self._grid8x3Button.grid(row=2,column=8)
        
        self._grid9x3Button = Button(self._theMap, image = self._grid9x3png, command = self._event9x3)
        self._grid9x3Button.grid(row=2,column=9)
        
        self._grid10x3Button = Button(self._theMap, image = self._grid10x3png, command = self._event10x3)
        self._grid10x3Button.grid(row=2,column=10)
        
        #row4
        self._grid1x4Button = Button(self._theMap, image = self._grid1x4png, command = self._event1x1)
        self._grid1x4Button.grid(row=3,column=1)
        
        self._grid2x4Button = Button(self._theMap, image = self._grid2x4png, command = self._event2x4)
        self._grid2x4Button.grid(row=3,column=2)
        
        self._grid3x4Button = Button(self._theMap, image = self._grid3x4png, command = self._event3x4)
        self._grid3x4Button.grid(row=3,column=3)
        
        self._grid4x4Button = Button(self._theMap, image = self._grid4x4png, command = self._event4x4)
        self._grid4x4Button.grid(row=3,column=4)
        
        self._grid5x4Button = Button(self._theMap, image = self._grid5x4png, command = self._event5x4)
        self._grid5x4Button.grid(row=3,column=5)
        
        self._grid6x4Button = Button(self._theMap, image = self._grid6x4png, command = self._event6x4)
        self._grid6x4Button.grid(row=3,column=6)
        
        self._grid7x4Button = Button(self._theMap, image = self._grid7x4png, command = self._event7x4)
        self._grid7x4Button.grid(row=3,column=7)
        
        self._grid8x4Button = Button(self._theMap, image = self._grid8x4png, command = self._event8x4)
        self._grid8x4Button.grid(row=3,column=8)
        
        self._grid9x4Button = Button(self._theMap, image = self._grid9x4png, command = self._event9x4)
        self._grid9x4Button.grid(row=3,column=9)
        
        self._grid10x4Button = Button(self._theMap, image = self._grid10x4png, command = self._event10x4)
        self._grid10x4Button.grid(row=3,column=10)
        
        
    #row5
        self._grid1x5Button = Button(self._theMap, image = self._grid1x5png, command = self._event1x5)
        self._grid1x5Button.grid(row=4,column=1)
        
        self._grid2x5Button = Button(self._theMap, image = self._grid2x5png, command = self._event2x5)
        self._grid2x5Button.grid(row=4,column=2)
        
        self._grid3x5Button = Button(self._theMap, image = self._grid3x5png, command = self._event3x5)
        self._grid3x5Button.grid(row=4,column=3)
        
        self._grid4x5Button = Button(self._theMap, image = self._grid4x5png, command = self._event4x5)
        self._grid4x5Button.grid(row=4,column=4)
        
        self._grid5x5Button = Button(self._theMap, image = self._grid5x5png, command = self._event5x5)
        self._grid5x5Button.grid(row=4,column=5)
        
        self._grid6x5Button = Button(self._theMap, image = self._grid6x5png, command = self._event6x5)
        self._grid6x5Button.grid(row=4,column=6)
        
        self._grid7x5Button = Button(self._theMap, image = self._grid7x5png, command = self._event7x5)
        self._grid7x5Button.grid(row=4,column=7)
        
        self._grid8x5Button = Button(self._theMap, image = self._grid8x5png, command = self._event8x5)
        self._grid8x5Button.grid(row=4,column=8)
       
        self._grid9x5Button = Button(self._theMap, image = self._grid9x5png, command = self._event9x5)
        self._grid9x5Button.grid(row=4,column=9)
        
        self._grid10x5Button = Button(self._theMap, image = self._grid10x5png, command = self._event10x5)
        self._grid10x5Button.grid(row=4,column=10)
        
    #row6
        self._grid1x6Button = Button(self._theMap, image = self._grid1x6png, command = self._event1x6)
        self._grid1x6Button.grid(row=5,column=1)
        
        self._grid2x6Button = Button(self._theMap, image = self._grid2x6png, command = self._event2x6)
        self._grid2x6Button.grid(row=5,column=2)
        
        self._grid3x6Button = Button(self._theMap, image = self._grid3x6png, command = self._event3x6)
        self._grid3x6Button.grid(row=5,column=3)
        
        self._grid4x6Button = Button(self._theMap, image = self._grid4x6png, command = self._event4x6)
        self._grid4x6Button.grid(row=5,column=4)
        
        self._grid5x6Button = Button(self._theMap, image = self._grid5x6png, command = self._event5x6)
        self._grid5x6Button.grid(row=5,column=5)
        
        self._grid6x6Button = Button(self._theMap, image = self._grid6x6png, command = self._event6x6)
        self._grid6x6Button.grid(row=5,column=6)
         
        self._grid7x6Button = Button(self._theMap, image = self._grid7x6png, command = self._event7x6)
        self._grid7x6Button.grid(row=5,column=7)
         
        self._grid8x6Button = Button(self._theMap, image = self._grid8x6png, command = self._event8x6)
        self._grid8x6Button.grid(row=5,column=8) 
         
        self._grid9x6Button = Button(self._theMap, image = self._grid9x6png, command = self._event9x6)
        self._grid9x6Button.grid(row=5,column=9)
         
        self._grid10x6Button = Button(self._theMap, image = self._grid10x6png, command = self._event10x6)
        self._grid10x6Button.grid(row=5,column=10)
#         
#     #row7
        self._grid1x7Button = Button(self._theMap, image = self._grid1x7png, command = self._event1x7)
        self._grid1x7Button.grid(row=6,column=1)
         
        self._grid2x7Button = Button(self._theMap, image = self._grid2x7png, command = self._event2x7)
        self._grid2x7Button.grid(row=6,column=2)
         
        self._grid3x7Button = Button(self._theMap, image = self._grid3x7png, command = self._event3x7)
        self._grid3x7Button.grid(row=6,column=3)
         
        self._grid4x7Button = Button(self._theMap, image = self._grid4x7png, command = self._event4x7)
        self._grid4x7Button.grid(row=6,column=4)
         
        self._grid5x7Button = Button(self._theMap, image = self._grid5x7png, command = self._event5x7)
        self._grid5x7Button.grid(row=6,column=5)
         
        self._grid6x7Button = Button(self._theMap, image = self._grid6x7png, command = self._event6x7)
        self._grid6x7Button.grid(row=6,column=6)
         
        self._grid7x7Button = Button(self._theMap, image = self._grid7x7png, command = self._event7x7)
        self._grid7x7Button.grid(row=6,column=7)
         
        self._grid8x7Button = Button(self._theMap, image = self._grid8x7png, command = self._event8x7)
        self._grid8x7Button.grid(row=6,column=8) 
         
        self._grid9x7Button = Button(self._theMap, image = self._grid9x7png, command = self._event9x7)
        self._grid9x7Button.grid(row=6,column=9)
     
        self._grid10x7Button = Button(self._theMap, image = self._grid10x7png, command = self._event10x7)
        self._grid10x7Button.grid(row=6,column=10)
#         
#     #row8
        self._grid1x8Button = Button(self._theMap, image = self._grid1x8png, command = self._event1x8)
        self._grid1x8Button.grid(row=7,column=1)
         
        self._grid2x8Button = Button(self._theMap, image = self._grid2x8png, command = self._event2x8)
        self._grid2x8Button.grid(row=7,column=2)
         
        self._grid3x8Button = Button(self._theMap, image = self._grid3x8png, command = self._event3x8)
        self._grid3x8Button.grid(row=7,column=3)
         
        self._grid4x8Button = Button(self._theMap, image = self._grid4x8png, command = self._event4x8)
        self._grid4x8Button.grid(row=7,column=4)
         
        self._grid5x8Button = Button(self._theMap, image = self._grid5x8png, command = self._event5x8)
        self._grid5x8Button.grid(row=7,column=5)
         
        self._grid6x8Button = Button(self._theMap, image = self._grid6x8png, command = self._event6x8)
        self._grid6x8Button.grid(row=7,column=6)
         
        self._grid7x8Button = Button(self._theMap, image = self._grid7x8png, command = self._event7x8)
        self._grid7x8Button.grid(row=7,column=7)
         
        self._grid8x8Button = Button(self._theMap, image = self._grid8x8png, command = self._event8x8)
        self._grid8x8Button.grid(row=7,column=8) 
         
        self._grid9x8Button = Button(self._theMap, image = self._grid9x8png, command = self._event9x8)
        self._grid9x8Button.grid(row=7,column=9)
     
        self._grid10x8Button = Button(self._theMap, image = self._grid10x8png, command = self._event10x8)
        self._grid10x8Button.grid(row=7,column=10)
#         
#     #row9
        self._grid1x9Button = Button(self._theMap, image = self._grid1x9png, command = self._event1x9)
        self._grid1x9Button.grid(row=8,column=1)
         
        self._grid2x9Button = Button(self._theMap, image = self._grid2x9png, command = self._event2x9)
        self._grid2x9Button.grid(row=8,column=2)
         
        self._grid3x9Button = Button(self._theMap, image = self._grid3x9png, command = self._event3x9)
        self._grid3x9Button.grid(row=8,column=3)
         
        self._grid4x9Button = Button(self._theMap, image = self._grid4x9png, command = self._event4x9)
        self._grid4x9Button.grid(row=8,column=4)
         
        self._grid5x9Button = Button(self._theMap, image = self._grid5x9png, command = self._event5x9)
        self._grid5x9Button.grid(row=8,column=5)
         
        self._grid6x9Button = Button(self._theMap, image = self._grid6x9png, command = self._event6x9)
        self._grid6x9Button.grid(row=8,column=6)
         
        self._grid7x9Button = Button(self._theMap, image = self._grid7x9png, command = self._event7x9)
        self._grid7x9Button.grid(row=8,column=7)
         
        self._grid8x9Button = Button(self._theMap, image = self._grid8x9png, command = self._event8x9)
        self._grid8x9Button.grid(row=8,column=8) 
         
        self._grid9x9Button = Button(self._theMap, image = self._grid9x9png, command = self._event9x9)
        self._grid9x9Button.grid(row=8,column=9)
     
        self._grid10x9Button = Button(self._theMap, image = self._grid10x9png, command = self._event10x9)
        self._grid10x9Button.grid(row=8,column=10)
#         
#     #row10
#         self._grid1x10Button = Button(self._theMap, image = self._grid1x10png, command = self._event1x10)
#         self._grid1x10Button.grid(row=9,column=1)
#          
#         self._grid2x10Button = Button(self._theMap, image = self._grid2x10png, command = self._event2x10)
#         self._grid2x10Button.grid(row=9,column=2)
#          
#         self._grid3x10Button = Button(self._theMap, image = self._grid3x10png, command = self._event3x10)
#         self._grid3x10Button.grid(row=9,column=3)
#          
#         self._grid4x10Button = Button(self._theMap, image = self._grid4x10png, command = self._event4x10)
#         self._grid4x10Button.grid(row=9,column=4)
#          
#         self._grid5x10Button = Button(self._theMap, image = self._grid5x10png, command = self._event5x10)
#         self._grid5x10Button.grid(row=9,column=5)
#          
#         self._grid6x10Button = Button(self._theMap, image = self._grid6x10png, command = self._event6x10)
#         self._grid6x10Button.grid(row=9,column=6)
#      
#         self._grid7x10Button = Button(self._theMap, image = self._grid7x10png, command = self._event7x10)
#         self._grid7x10Button.grid(row=9,column=7)
#          
#         self._grid8x10Button = Button(self._theMap, image = self._grid8x10png, command = self._event8x10)
#         self._grid8x10Button.grid(row=9,column=8) 
#          
#         self._grid9x10Button = Button(self._theMap, image = self._grid9x10png, command = self._event9x10)
#         self._grid9x10Button.grid(row=9,column=9)
#      
#         self._grid10x10Button = Button(self._theMap, image = self._grid10x10png, command = self._event10x10)
#         self._grid10x10Button.grid(row=9,column=10)
        self.rowconfigure(2, weight = 2)
        self._theMap.rowconfigure(2, weight = 2)
        
    def _event1x1 (self):
        gridX = 1
         
    def _event1x2 (self):
        gridX = 1 
    
    def _event1x3 (self):
        gridX = 1
    
    def _event1x4 (self):
        gridX = 1
    
    def _event1x5 (self):
        gridX = 1
    
    def _event1x6 (self):
        gridX = 1    
    
    def _event1x7 (self):
        gridX = 1
    
    def _event1x8 (self):
        gridX = 1
    
    def _event1x9 (self):
        gridX = 1
    
    def _event1x10 (self):
        gridX = 1

        
        
    def _event2x1 (self):
        gridX = 1
    
    def _event2x2 (self):
        gridX = 1 
    
    def _event2x3 (self):
        gridX = 1
    
    def _event2x4 (self):
        gridX = 1
    
    def _event2x5 (self):
        gridX = 1
    
    def _event2x6 (self):
        gridX = 1    
    
    def _event2x7 (self):
        gridX = 1
    
    def _event2x8 (self):
        gridX = 1
    
    def _event2x9 (self):
        gridX = 1
    
    def _event2x10 (self):
        gridX = 1
    
    
    
    def _event3x1 (self):
        gridX = 1
    
    def _event3x2 (self):
        gridX = 1 
    
    def _event3x3 (self):
        gridX = 1
    
    def _event3x4 (self):
        gridX = 1
    
    def _event3x5 (self):
        gridX = 1
    
    def _event3x6 (self):
        gridX = 1    
    
    def _event3x7 (self):
        gridX = 1
    
    def _event3x8 (self):
        gridX = 1
    
    def _event3x9 (self):
        gridX = 1
    
    def _event3x10 (self):
        gridX = 1
        
        
        
        
    def _event4x1 (self):
        gridX = 1
    
    def _event4x2 (self):
        gridX = 1 
    
    def _event4x3 (self):
        gridX = 1
    
    def _event4x4 (self):
        gridX = 1
    
    def _event4x5 (self):
        gridX = 1
    
    def _event4x6 (self):
        gridX = 1    
    
    def _event4x7 (self):
        gridX = 1
    
    def _event4x8 (self):
        gridX = 1
    
    def _event4x9 (self):
        gridX = 1
    
    def _event4x10 (self):
        gridX = 1    
        
        
    def _event5x1 (self):
        gridX = 1
    
    def _event5x2 (self):
        gridX = 1 
    
    def _event5x3 (self):
        gridX = 1
    
    def _event5x4 (self):
        gridX = 1
    
    def _event5x5 (self):
        gridX = 1
    
    def _event5x6 (self):
        gridX = 1    
    
    def _event5x7 (self):
        gridX = 1
    
    def _event5x8 (self):
        gridX = 1
    
    def _event5x9 (self):
        gridX = 1
    
    def _event5x10 (self):
        gridX = 1    
        
        
    def _event6x1 (self):
        gridX = 1
    
    def _event6x2 (self):
        gridX = 1 
    
    def _event6x3 (self):
        gridX = 1
    
    def _event6x4 (self):
        gridX = 1
    
    def _event6x5 (self):
        gridX = 1
    
    def _event6x6 (self):
        gridX = 1    
    
    def _event6x7 (self):
        gridX = 1
    
    def _event6x8 (self):
        gridX = 1
    
    def _event6x9 (self):
        gridX = 1
    
    def _event6x10 (self):
        gridX = 1
        
        
        
        
    def _event7x1 (self):
        gridX = 1
    
    def _event7x2 (self):
        gridX = 1 
    
    def _event7x3 (self):
        gridX = 1
    
    def _event7x4 (self):
        gridX = 1
    
    def _event7x5 (self):
        gridX = 1
    
    def _event7x6 (self):
        gridX = 1    
    
    def _event7x7 (self):
        gridX = 1
    
    def _event7x8 (self):
        gridX = 1
    
    def _event7x9 (self):
        gridX = 1
    
    def _event7x10 (self):
        gridX = 1
        
        
        
    def _event8x1 (self):
        gridX = 1
    
    def _event8x2 (self):
        gridX = 1 
    
    def _event8x3 (self):
        gridX = 1
    
    def _event8x4 (self):
        gridX = 1
    
    def _event8x5 (self):
        gridX = 1
    
    def _event8x6 (self):
        gridX = 1    
    
    def _event8x7 (self):
        gridX = 1
    
    def _event8x8 (self):
        gridX = 1
    
    def _event8x9 (self):
        gridX = 1
    
    def _event8x10 (self):
        gridX = 1
        
        
        
    def _event9x1 (self):
        gridX = 1
    
    def _event9x2 (self):
        gridX = 1 
    
    def _event9x3 (self):
        gridX = 1
    
    def _event9x4 (self):
        gridX = 1
    
    def _event9x5 (self):
        gridX = 1
    
    def _event9x6 (self):
        gridX = 1    
    
    def _event9x7 (self):
        gridX = 1
    
    def _event9x8 (self):
        gridX = 1
    
    def _event9x9 (self):
        gridX = 1
    
    def _event9x10 (self):
        gridX = 1
        
        
        
        
    def _event10x1 (self):
        gridX = 1
    
    def _event10x2 (self):
        gridX = 1 
    
    def _event10x3 (self):
        gridX = 1
    
    def _event10x4 (self):
        gridX = 1
    
    def _event10x5 (self):
        gridX = 1
    
    def _event10x6 (self):
        gridX = 1    
    
    def _event10x7 (self):
        gridX = 1
    
    def _event10x8 (self):
        gridX = 1
    
    def _event10x9 (self):
        gridX = 1
    
    def _event10x10 (self):
        gridX = 1
    
    
def main():
    
    name = input("Hello, what is your name: ")
    #inputNameIntoList()
    answer = input("Are you homeless " + name.title() + "? Y/N")
    
    #If user has home
    if answer == "N" or answer == "n":
        #Reason for needing assistance
        print("Please tell me the reason you need help.")
        showMenu1()
        reason = input("Enter in the number corresponding to the reason please: ")
        
        if reason == "Loss of income" or reason == "abuse" or reason == "addiction" or \
        reason == "medical debt" or reason == "mental illness" or \
        reason == "1" or reason == "2" or reason == "3" or reason == "4" or reason == "5" or reason == "6":
            
            
            print("\nI'm sorry to hear that. Thank you for telling us. \nWe will use this information to help prevent the loss of your home.")
            #inputReasonIntoList()
            print("Here are the list of possible resource to help you.")
            resourceList()
        else:
            other = input("Please tell me why you need help: ")
            showMenu2()
            print("I'm sorry to hear that. Thank you for telling us. \
                We will use this information to help you.")
            
    #No homeless
    elif answer == "Y" or answer == "y":
        location = input("Please tell me where can I find you? (Ex: Grid Location, Street name, Address, Interection, City, State, Zip or )")
        #inputLocationInListGui()
        #inputLocationMenuGui()
        serviceMenu()
        service = input("Please tell me what you need help with by entering the number from the menu below: ")
        
        if service == "1":
            service1()
        elif service == "2":
            print("hi")#replace with def()
        elif service == "3":
            print("hi")
        elif service == "4":
            print("hi")
        elif service == "5":
            print("hi")
        elif service == "6":
            print("hi")
def showMenu2():
    print("1. Emergency Shelter")
    print("2. Food")
    print("3. Blanket")
    print("4. Recovery Programs")
    print("5. Job Programs")
    print("6. Other")

#Resource list
def resourceList():
    print("Here are some of the resources we have to offer: ")
    print("1. Emergency Shelter")
    print("2. Affordable Housing")
    print("3. Homelessness Assistance")
    
#Reason needing help menu: Not Homeless.
def showMenu1():
    print("1. 'Loss of income'")
    print("2. 'Abuse'")
    print("3. 'Addiction'")
    print("4. 'Medical Debt'")
    print("5. 'Job Programs'")
    print("6. 'Other'")

#Services
def serviceMenu():
    print("Here are some of the resources we have to offer: ")
    print("1. Emergency Shelter")
    print("2. Food")
    print("3. Blankets")
    print("4. Recovery Program")
    print("5. Job Program")
    print("6. Other")

def service1():
    f = open("Service1.txt", "r")
    Location = {}
    
    for line in f:
        line = line.strip()#No more white space
        line = line.split()#made words into list

        for word in line:
            word = word.strip()
            if not word in Location:
                Location[word] = []

    print ("%-50s" %("Shelter Names: "))
    for key in sorted(Location):
        print ('%-50s' % (key))

def service2():
    f = open(input("Enter a filename: "), "r")
    Dictionary = {}
    linenumber = 0
    
    for line in f:
        line = line.strip()#No more white space
        line = line.lower()#all lower case
        line = line.split()#made words into list
        linenumber += 1
        for word in line:
            word = word.strip()
            word = word.lower()
    
            if not word in Dictionary:
                Dictionary[word] = []
            Dictionary[word].append(linenumber)
    print ("%-50s %11s  %-35s" %("Word", 'Frequency', "Line Numbers"))
    for key in sorted(Dictionary):
        print ('%-50s %11d: %-35s' % (key, len(Dictionary[key]), Dictionary[key]))
        
def service3():
    f = open(input("Enter a filename: "), "r")
    Dictionary = {}
    linenumber = 0
    
    for line in f:
        line = line.strip()#No more white space
        line = line.lower()#all lower case
        line = line.split()#made words into list
        linenumber += 1
        for word in line:
            word = word.strip()
            word = word.lower()
    
            if not word in Dictionary:
                Dictionary[word] = []
            Dictionary[word].append(linenumber)
    print ("%-50s %11s  %-35s" %("Word", 'Frequency', "Line Numbers"))
    for key in sorted(Dictionary):
        print ('%-50s %11d: %-35s' % (key, len(Dictionary[key]), Dictionary[key]))

def service4():
    f = open(input("Enter a filename: "), "r")
    Dictionary = {}
    linenumber = 0
    
    for line in f:
        line = line.strip()#No more white space
        line = line.lower()#all lower case
        line = line.split()#made words into list
        linenumber += 1
        for word in line:
            word = word.strip()
            word = word.lower()
    
            if not word in Dictionary:
                Dictionary[word] = []
            Dictionary[word].append(linenumber)
    print ("%-50s %11s  %-35s" %("Word", 'Frequency', "Line Numbers"))
    for key in sorted(Dictionary):
        print ('%-50s %11d: %-35s' % (key, len(Dictionary[key]), Dictionary[key]))
        
def service5():
    f = open(input("Enter a filename: "), "r")
    Dictionary = {}
    linenumber = 0
    
    for line in f:
        line = line.strip()#No more white space
        line = line.lower()#all lower case
        line = line.split()#made words into list
        linenumber += 1
        for word in line:
            word = word.strip()
            word = word.lower()
    
            if not word in Dictionary:
                Dictionary[word] = []
            Dictionary[word].append(linenumber)
    print ("%-50s %11s  %-35s" %("Word", 'Frequency', "Line Numbers"))
    for key in sorted(Dictionary):
        print ('%-50s %11d: %-35s' % (key, len(Dictionary[key]), Dictionary[key]))
        
def service6():
    f = open(input("Enter a filename: "), "r")
    Dictionary = {}
    linenumber = 0
    
    for line in f:
        line = line.strip()#No more white space
        line = line.lower()#all lower case
        line = line.split()#made words into list
        linenumber += 1
        for word in line:
            word = word.strip()
            word = word.lower()
    
            if not word in Dictionary:
                Dictionary[word] = []
            Dictionary[word].append(linenumber)
    print ("%-50s %11s  %-35s" %("Location", 'Address', "Phone Number"))
    for key in sorted(Dictionary):
        print ('%-50s %11d: %-35s' % (key, len(Dictionary[key]), Dictionary[key]))
        
    #homelessGUI().mainloop()
